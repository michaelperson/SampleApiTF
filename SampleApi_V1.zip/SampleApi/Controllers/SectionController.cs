﻿using Exo_Linq_Context;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SampleApi.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class SectionController : ControllerBase
	{
		private IContext _ctx;

		public SectionController(IContext context)
		{
			_ctx = context;
		}

		[HttpGet]
		public IEnumerable<Section> GetAll()
		{
			 return _ctx.Sections;
		}
		[HttpPost]	 
		public void CreateSection([FromBody]Section sec)
		{

			_ctx.Sections.Add(sec);
		}
	}
}
