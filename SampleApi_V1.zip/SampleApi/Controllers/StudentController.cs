﻿using Exo_Linq_Context;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SampleApi.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class StudentController : ControllerBase
	{
		private IContext _ctx;

		public StudentController(IContext context)
		{
			_ctx = context;
		}

		[HttpGet]
		public IEnumerable<Student> GetAllStudent()
		{
			 
			return _ctx.Students;
		}

		[HttpGet]
		[Route("{idStudent:int}")]
		public Student? GetStudentById(int idStudent)
		{
			 
			return _ctx.Students.SingleOrDefault(s => s.Student_ID == idStudent);
		}

		[HttpGet]
		[Route("section/{sectionId:int}")]
		public IEnumerable<Student> GetStudentBySectionId(int sectionId)
		{
			 
			return _ctx.Students.Where(s => s.Section_ID == sectionId);
		}

		[HttpGet]
		[Route("{name:alpha}")]
		public Student? GetStudentByName(string name)
		{
			 
			return _ctx.Students.SingleOrDefault(s => s.Last_Name == name);
		}


	}
}
