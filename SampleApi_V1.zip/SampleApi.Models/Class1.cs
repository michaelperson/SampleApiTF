﻿namespace SampleApi.Models
{
	public class Utilisateur
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public DateTime DateDeNaissance { get; set; }
	}
}