﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleApi.Models
{
	public class SectionDTO
	{
		public int Section_Id { get; set; }
		public string Section_Name { get; set; }
		public int Delegate_id { get; set; }
	}
}
