﻿using Exo_Linq_Context;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace SampleApi.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class SectionController : ControllerBase
	{
		private IContext _ctx;

		public SectionController(IContext context)
		{
			_ctx = context;
		}
		/// <summary>
		/// Permet de récupérer toutes les sections
		/// </summary>
		/// <returns>Un <see cref="IEnumerable{Section}"/></returns>
		
		[HttpGet] 		
		public IActionResult GetAll()
		{
			try
			{
				return Ok(_ctx.Sections);
			}
			catch (Exception)
			{
				return NotFound();
			}
		}

		[HttpGet]
		[Route("{id:int}")]
		public IActionResult Get(int id)
		{
			return Ok(_ctx.Sections.SingleOrDefault(s=>s.Section_ID==id));
		}

		[HttpDelete]
		[Route("{id:int}")]
		public IActionResult Delete(int id)
		{
			Section secToDelete = _ctx.Sections.SingleOrDefault(s => s.Section_ID == id);
			if(secToDelete != null)
			{
				_ctx.Sections.Remove(secToDelete);
				return NoContent();
			}
			else
			{
				return NotFound();
			}
			 
		}

		[HttpPost]	 
		public IActionResult CreateSection([FromBody]Section sec)
		{

			try
			{
				_ctx.Sections.Add(sec);
				return new CreatedResult($"https://localhost:7025/api/Section/{sec.Section_ID}", sec);
				 
			}
			catch (Exception ex)
			{

				return BadRequest(ex.Message);
			}
		}
	}
}
